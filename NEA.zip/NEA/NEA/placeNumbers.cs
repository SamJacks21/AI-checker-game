﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NEA__window_
{
    public class placeNumbers
    {
        public int x;

        public placeNumbers()
        {
            x = 0;
        }

        public placeNumbers(int xx)
        {
            x = xx;
        }
    }
}
